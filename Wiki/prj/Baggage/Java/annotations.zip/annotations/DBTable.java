// 2)

//Файл annotations\DBTable.java ------------------------------------------------------------------------------
package annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface DBTable
{
  //Для немаркерных аннотаций задаются элементы (параметры) аннотаций
  public int id();                  //Обязательный параметр
  public String name() default "";  //Необязательный параметр, если не задан, то используется значение по умолчанию

  /* Все параметры (элементы аннотоций) могут быть следующих типов:
  *  1) все примитивные типы,
  *  2) String
  *  3) Class
  *  4) enum
  *  5) Annotation
  *  6) Массивы всех выше перечисленных типов
  *
  *  Все ссылочные типы не могут быть null, ни по умолчанию, ни в месте использования аннотации
  */
}
