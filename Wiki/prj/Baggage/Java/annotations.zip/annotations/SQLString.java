// 4)

//annotations\SQLString.java ---------------------------------------------------------------------------------
package annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface SQLString
{
  //value - это особое имя для параметра аннотации, оно позволяет использовать сокращенную форму записи
  int value() default 0;
  String name() default "";
  Constraints constraints() default @Constraints; //Необязательный параметр типа аннотация
  //Так как аннотация @Constraints не имеет обязательных полей, то в данном случае будут использованы значения по умолчанию
  //  ниже представлен пример поля с типом аннотации с указанием значения
  //Constraints constraints() default @Constraints(primaryKey = true); //Необязательный параметр типа аннотация
}
