// 5)

//annotations\Member.java ------------------------------------------------------------------------------------
package annotations;

//Помечаем аннотацией класс
@DBTable(id=0, name = "MEMBER")
public class Member
{
  //Помечаем аннотацией(иями) поле
  @Marker
  @SQLString(30) //Можно использовать сокращенную записи для параметра аннотации имеющего имя "value" и если
                 //  если это единственный задаваемый параметр
  private String firstName;
  
  //Задаем несколько параметров аннотации, используем синтаксис "ключ = значение"
  @SQLString(value = 30, constraints = @Constraints(primaryKey = true))
  private String handle;
  
  static int memberCount;
  
  public String getFirstName()
  {
    return firstName;
  }
  public String getHandle()
  {
    return handle;
  }
  public static int getMemberCount()
  {
    return memberCount;
  }
}
