// 6)

//файл annotations\TableCreator.java

/* А теперь, для примера, посмотрим как можно использовать метаданные
*  Используем рефлексию (отражения), что бы сгенерировать ddl SQL код
*/
package annotations;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class TableCreator
{
  public static void main(String[] args) throws Exception
  {
    Class<Member> cl = Member.class;

    DBTable dbTable = cl.getAnnotation(DBTable.class); //Ищем DBTable аннотацию класса
    if(dbTable != null)
    {
      //Находим имя таблицы
      String tableName = dbTable.name();        //Либо name из аннотации
      if(tableName.length() < 1)                //  либо если name не задан
        tableName = cl.getName().toUpperCase(); //  используем имя java класса
  
      //Начинаем формировать ddl sql код таблицы
      String createCommand = new String("\nCREATE TABLE " + tableName + "\n(\n");
  
      List<String> columns = new ArrayList<String>();
      for(Field field : cl.getDeclaredFields()) //Проходим по полям java класса
      {
        Annotation[] annotations = field.getDeclaredAnnotations(); //Извлекаем аннотации очередного поля
        if(annotations.length < 1)
          continue;
        for(Annotation annotation : annotations)
        {
          
          //Если аннотация имеет тип SQLString
          if(annotation instanceof SQLString)
          {
            SQLString ss = (SQLString)annotation;
            //Находим имя столбца таблицы
            String columnName = null;
            if(ss.name().length() < 1)
              columnName = field.getName().toUpperCase();
            else
              columnName = ss.name();
            Constraints constraints = ss.constraints(); //Получаем поданнотацию с ограничениями
            //Добавляем в ddl код столбец таблицы
            createCommand += "    " + columnName + " VARCHAR(" + ss.value() + ")" + getConstraints(constraints) + "\n";
          }
  
          //Если аннотация имеет тип SQL...
          //...
          
        }
      }
      //Добавляем в код ddl закрывающую );
      createCommand += ");\n";
      
      System.out.print(createCommand);
    }
  }
  private static String getConstraints(Constraints con)
  {
    //Формируем ddl код с SQL ограничениями
    String constraints = "";
    if(!con.allowNull())
      constraints += " NOT NULL";
    if(con.primaryKey())
      constraints += " PRIMARY KEY";
    if(con.unique())
      constraints += " UNIQUE";
    return constraints;
  }
}
